WTWR (What to Wear?)

About the project The idea of the application is pretty simple - we make a call to an API, which then responds with the daily weather forecast. We collect the weather data, process it, and then based on the forecast, we recommend suitable clothing to the user.
Tools and Technology Used

This application currently uses HTML, CSS, Javascript, and React.
Plans for Improvement

Future improvements include adding more weather and clothing options. Users will be able to add their own clothing selections for different weather types. The site will also be updated to be responsive to different screen sizes. There will also be different weather images uploaded based on the weather. Lastly this page will be deployed to github.
Link to Back End Project

https://github.com/saumyanaya/se_project_express
