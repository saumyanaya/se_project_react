import "./Footer.css";

const Footer = () => {
  return (
    <footer className="footer">
      <div>Developed by Practicum Students Saumya Nayak</div>
      <div>2023</div>
    </footer>
  );
};
export default Footer;
